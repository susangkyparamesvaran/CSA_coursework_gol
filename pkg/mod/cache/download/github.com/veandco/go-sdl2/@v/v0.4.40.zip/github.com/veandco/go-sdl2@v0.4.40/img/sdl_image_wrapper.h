#if defined(__WIN32)
	#include <SDL2/SDL_image.h>
	#include <stdlib.h>
#else
	#include <SDL_image.h>
#endif

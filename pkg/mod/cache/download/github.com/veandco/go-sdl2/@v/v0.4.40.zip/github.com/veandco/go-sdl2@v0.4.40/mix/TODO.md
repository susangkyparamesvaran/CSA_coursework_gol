## 2.0.2

- [ ] OpenAudioDevice()

## 2.0.0

- [ ] UnregisterEffect()
- [ ] SetPostMix()
- [ ] HookMusic()
- [ ] HookMusicFinished()
- [ ] ChannelFinished()
- [ ] RegisterEffect()
- [ ] UnregisterAllEffects()
- [ ] EachSoundFont()

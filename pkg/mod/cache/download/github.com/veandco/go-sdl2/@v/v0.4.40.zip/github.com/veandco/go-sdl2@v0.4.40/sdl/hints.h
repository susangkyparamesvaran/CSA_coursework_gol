void hintCallback(void *userdata, const char *name, const char *oldValue, const char *newValue);
void addHintCallback(const char *name);
void delHintCallback(const char *name);

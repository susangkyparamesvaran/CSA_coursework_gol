#if defined(__WIN32)
	#include <SDL2/SDL2_framerate.h>
	#include <SDL2/SDL2_gfxPrimitives.h>
	#include <SDL2/SDL2_imageFilter.h>
	#include <SDL2/SDL2_rotozoom.h>
	#include <stdlib.h>
#else
	#include <SDL2_framerate.h>
	#include <SDL2_gfxPrimitives.h>
	#include <SDL2_imageFilter.h>
	#include <SDL2_rotozoom.h>
#endif
